<?php include 'header.php';
require 'functions.php'; ?>

<div id="carouselExampleIndicators" class="carousel slide">


</div>

<div class="btn-group" role="group" aria-label="Basic checkbox toggle button group">
  <input type="checkbox" class="btn-check" id="btncheck1" autocomplete="off">
  <label class="btn btn-outline-primary" for="categorie">fleure</label>

  <input type="checkbox" class="btn-check" id="btncheck2" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck2">Plant</label>

  <input type="checkbox" class="btn-check" id="btncheck3" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck3">Outillage</label>

  <input type="checkbox" class="btn-check" id="btncheck4" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck4">Matériel</label>

  <input type="checkbox" class="btn-check" id="btncheck5" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck5"></label>

  <input type="checkbox" class="btn-check" id="btncheck6" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck6"></label>

  <input type="checkbox" class="btn-check" id="btncheck7" autocomplete="off">
  <label class="btn btn-outline-primary" for="btncheck7"></label>

 
</div>

<div class="promo">

  <h2>Produits vedettes</h2>

  <img class="vedette"src="img/outillage.jpg" class="img-fluid" alt="">

<br>
  <h2>Marques vedettes</h2>

  <p>Pierre</p>
  <p>Paul</p>
  <p>Jack</p>

<br>
  <h2>Quoi de neuf</h2>

  <img src="img/affiche.jpg" class="img-fluid" alt="evenement">
</div>
<br>
  <?php include 'footer.php'; ?>

