INSERT INTO `t_d_user` (`Id_User`, `Id_UserType`, `Login`, `Password`) VALUES
(12, 2, 'TATA', '$2y$10$aGh0yRjuEY8uCSQZEQ2vIuTUeq0kHAAOz61y2AE0SqHpz3dPw0eIe'),
(13, 3, 'TETE', '$2y$10$wq/Rg5awWeFo3kzNNIqU9.m8j92C2da4GvWS/QM64L1J6CjcQecZ6'),
(14, 3, 'TITI', '$2y$10$Ub5Ldkm2bm.5GWKmTC7JiuGVFUmz.JcEzjCqZntRXfHjcZFTnrT4K'),
(15, 1, 'TOTO', '$2y$10$DnZ2XLtPsMviPFIsRQaKKOwwOR2U72WT06aXn2ystNsSmMA/1su4C'),
(16, 1, 'TUTU', '$2y$10$YMhyYbjhaP2tP2Dopn34/ey6.BExuj9gQwBWDxvXSQpXIZUSYwZqG'),
(17, 1, 'TYTY', '$2y$10$HU9MpMvUiyjuDPCt5ejWMuQMyxPmJqBnI9ILyhxqlxwpvNRIgkP3e'),
(18, 1, 'TLTL', '$2y$10$vBFzEUzLTD//nGcdvW3hF.ALCeFVqICrAtZ1OOnm90ZP.eodjuBh.'),
(19, 1, 'TRTR', '$2y$10$RAzLAQ6SJtKIE0gXedlAmuUwjSHCOAWugtEQuJeCYvA0qpI/psj8q'),
(20, 1, 'LILI', '$2y$10$2Nk.AG/fHA.ylv05r81VZOkuMsLaCY9y/X5du7JXn2i59R23vJVoy'),
(21, 1, 'LULU', '$2y$10$iohAIxnRuu/vr7DZhaVCUet5YJQXRCG87m0irBzH94zkI80Ce3qk2');

INSERT INTO t_d_usertype(Id_UserType,Libelle)VALUES 
(4,'Technicien SAV');
