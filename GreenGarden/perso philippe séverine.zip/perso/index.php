<?php include 'header.php';
require 'functions.php'; ?>





<div class="promo">

  <h2>Produits vedettes</h2>

  <img class="vedette"src="img/outillage.jpg" class="img-fluid" alt="">

<br>
  <h2>Marques vedettes</h2>

  <p>Pierre</p>
  <p>Paul</p>
  <p>Jack</p>

<br>
  <h2>Quoi de neuf</h2>

  <img src="img/affiche.jpg" class="img-fluid" alt="evenement">
</div>
<br>
  <?php include 'footer.php'; ?>

