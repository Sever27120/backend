<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exo3</title>
</head>
<body>
    <?php
//---Affichez l'heure courante sous cette forme : 11h25.
$heure = date('H\hi');
echo $heure;




?>
    
</body>
</html>