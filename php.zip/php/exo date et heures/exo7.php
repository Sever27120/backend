<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exo5</title>
</head>
<body>
 <?php
//---Que s'est-il passé le 1000200000 ?
$date = date('Y-m-d H:i:s', 1000200000);
echo $date "c'est la date des attentats des 2 tours World Trade Center qui s'effondrent";


?>



    
</body>
</html>