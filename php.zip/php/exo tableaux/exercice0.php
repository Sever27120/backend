<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exercice 0 tablo</title>
</head>
<body>
    <?php
    $tab= array ("Lundi","Mardi","Mercredi","Jeudi","Vendredi");
    
    var_dump($tab);

    $factures=array("Janvier"=>500,"Février"=>620,"Mars"=>300,"Avril"=>130,"Mai"=>560,"Juin"=>350);

    var_dump($factures);

    ?>


</body>
</html>
