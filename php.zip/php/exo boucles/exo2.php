<?php
for ($i=0500; $i <500 ; $i++) { 
    echo "Je dois faire des sauvegardes régulières de mes fchiers.<br>";
}
?>
