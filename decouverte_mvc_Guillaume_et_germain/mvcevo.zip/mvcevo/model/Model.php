<?php
abstract class Model{
    private $bdd;

// récupère un billet avec son id
// public function getBillet($idBillet)
// {
//     $bdd = $this->getBdd();
//     $billet = $bdd->prepare('SELECT BIL_ID as id, BIL_DATE as date, BIL_TITRE as
// titre, BIL_CONTENU as contenu FROM T_BILLET WHERE BIL_ID =?;');
//     $billet->execute(array($idBillet));

//     if ($billet->rowCount() == 1) {
//         return $billet->fetch();

//     } 
//     else {
//         throw new Exception("Aucun billet ne correspond à cet identifiant");
//     }
// }

// public function getBillets()
// {
//     //accès aux données
//     $bdd = $this->getBdd();
//     return $bdd->query('SELECT BIL_ID as id, BIL_DATE as date, BIL_TITRE as titre, BIL_CONTENU as contenu FROM T_BILLET order by BIL_ID desc');
    
// }

private function getBdd()
{
    if ($this->bdd == null){
        $this->bdd = new PDO("mysql:host=localhost;dbname=blog;charset=utf8",'root','',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }
   return $this->bdd;   
}


// public function getComments($idBillet)
// {
//     $bdd = $this->getBdd();
//     $comments=$bdd->prepare('SELECT COM_ID as id, COM_DATE as date, COM_AUTEUR as auteur, 
//     COM_CONTENU as contenu FROM T_COMMENTAIRE WHERE BIL_ID=?');
//     $comments->execute(array($idBillet));
//     return $comments;
// }

protected function executerRequete($sql, $params = null)
{
    if ($params == null){
        $resultat = $this ->getBdd()->query($sql);// exécution directe
    }
    else{
        $resultat= $this->getBdd()->prepare($sql);// requête préparée
        $resultat->execute($params);
    }
    return $resultat;
}

}