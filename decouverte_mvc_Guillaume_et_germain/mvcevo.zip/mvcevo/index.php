<?php
require 'controller/router.php';

$r=new Routeur();
$r->routerRequete();